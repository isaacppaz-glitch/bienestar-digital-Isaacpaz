# 🌟 Isaac Paz | Bienestar Digital - ACTUALIZADO

Sitio web profesional de una sola página para el nicho de salud crónica/diabetes para latinos.

## ✅ Características Implementadas

### 📄 **Archivo Único HTML**
- ✅ Todo en un solo archivo `index.html`
- ✅ 100% autónomo (CSS y JavaScript inline)
- ✅ Sin dependencias locales (solo CDN: Google Fonts, Font Awesome)
- ✅ Listo para arrastrar y soltar en cualquier hosting

### 🎨 **Diseño Profesional**
- ✅ Paleta de colores premium: Navy (#0A1F3C), Dorado (#C9A84C), Verde (#1B5E3B)
- ✅ Tipografía elegante: Playfair Display + Inter
- ✅ 8+ imágenes de alta calidad de Unsplash
- ✅ **✨ NUEVO: Foto familiar tranquilizadora** en sección Mi Historia
- ✅ Responsive mobile-first
- ✅ Animaciones fade-in al hacer scroll
- ✅ Navbar fijo con glassmorphism

### 🛍️ **Botones Flotantes (ACTUALIZADO)**
- ✅ **✨ NUEVO: Botón Tienda fluorescente** (Rosa neón #FF10F0 + Cyan #00F5FF) con animación pulse
- ✅ Botón WhatsApp con animación
- ✅ Botón "Volver arriba"
- ✅ **✨ Todos los enlaces de WhatsApp actualizados:** https://chat.whatsapp.com/G63cumGwyTl9WCyfqQwZbX?mode=gi_t

### 📑 **Secciones Incluidas**

1. **#inicio** - Hero principal con estadísticas (3,000+ seguidores)
2. **#historia** - Historia personal con **foto familiar tranquilizadora**
3. **#recursos** - Grid de recursos gratuitos
4. **#ebooks** - Ebooks gratuitos con badges de urgencia
5. **#articulos** - Blog con cards de artículos
6. **#herramientas** - Calculadoras y herramientas prácticas
7. **#comunidad** - Facebook + WhatsApp con stats
8. **#tienda** - **✨ Amazon + Shopify** con psicología de compra
9. **#suscribete** - Formulario de captura (placeholder para Tally)
10. **#privacidad** - Disclaimer en footer

### 🛒 **Sección Tienda (MEJORADA)**
- ✅ **✨ NUEVO: 2 Plataformas destacadas:** Amazon + Shopify con cards animadas
- ✅ Colores estratégicos: naranja Amazon (#FF6600), verde Shopify (#96BF48), rojo urgencia (#E63946)
- ✅ Badges animados: "Más Vendido", "Recomendado", "Oferta Limitada"
- ✅ Urgencia: "Solo quedan X unidades" / "X personas vieron esto hoy"
- ✅ Precios tachados con % de ahorro
- ✅ Estrellas de valoración 4.8/5
- ✅ Garantía 30 días con iconos de confianza
- ✅ Botones grandes con animación pulse
- ✅ Elementos de confianza: Compra Segura, Envío Rápido, Devolución Fácil

### ⚡ **Funcionalidades**
- ✅ Navegación por anclas (#seccion)
- ✅ Navbar con menú hamburguesa móvil
- ✅ **✨ Botón tienda fluorescente flotante (rosa neón + cyan)**
- ✅ Botón WhatsApp flotante con animación pulse
- ✅ Botón "Volver arriba" flotante
- ✅ Smooth scroll entre secciones
- ✅ Intersection Observer para animaciones
- ✅ 100% funcional sin JavaScript externo
- ✅ **✨ WhatsApp actualizado en TODOS los lugares**

## 🚀 Cómo Publicar

### **Opción 1: Cloudflare Pages (RECOMENDADO)**

1. Ve a [pages.cloudflare.com](https://pages.cloudflare.com)
2. Clic en **"Upload your static files"**
3. Arrastra y suelta `index.html`
4. Deploy automático en 30 segundos
5. Conecta tu dominio `isaacpazebook.com` desde Custom Domains

### **Opción 2: Tiiny.host (Más rápido)**

1. Ve a [tiiny.host](https://tiiny.host)
2. Arrastra `index.html`
3. URL pública al instante
4. Para dominio propio: plan de pago ~$5/mes

## 📝 Tareas Pendientes

### 🔴 **Urgente - Configurar Formulario de Captura**

El formulario de suscripción está con un placeholder. Para activarlo:

**Usando Tally.so (Recomendado - GRATIS):**

1. Crea cuenta en [tally.so](https://tally.so)
2. Crea formulario con:
   - Campo: **Nombre**
   - Campo: **Email**
3. En configuración activa:
   - "Redirect to URL after submission" → pega link de tu PDF ebook
4. Ve a "Share" → copia código "Embed"
5. Reemplaza en `index.html` el div con clase `suscripcion-form-placeholder` por:

```html
<iframe 
  src="https://tally.so/embed/TU-ID-AQUI" 
  width="100%" 
  height="400" 
  frameborder="0" 
  marginheight="0" 
  marginwidth="0" 
  title="Formulario de Suscripción">
</iframe>
```

### 🔗 **Actualizar Links de Productos**

**Links que necesitas actualizar:**

```html
Productos Amazon (líneas ~2050-2128):
href="https://www.amazon.com"
Reemplaza con links reales de afiliado de Amazon

Plataforma Amazon (línea ~1998):
href="https://www.amazon.com"
Reemplaza con tu página principal de Amazon

Tienda Shopify (línea ~2008):
href="https://www.shopify.com"
Reemplaza con tu tienda Shopify real

Email contacto (línea ~2271):
mailto:contacto@isaacpazebook.com
Cambia al email real
```

### ✅ **COMPLETADO EN ESTA ACTUALIZACIÓN**
- ✅ Foto familiar tranquilizadora en sección Historia
- ✅ Botón flotante tienda con colores fluorescentes (rosa neón + cyan)
- ✅ Integración de Shopify en tienda con cards destacadas
- ✅ WhatsApp actualizado en TODOS los enlaces: https://chat.whatsapp.com/G63cumGwyTl9WCyfqQwZbX?mode=gi_t

## 📊 Estadísticas del Proyecto

- **Tamaño del archivo:** ~78 KB
- **Líneas de código:** ~2,350
- **Imágenes de Unsplash:** 8
- **Secciones:** 10
- **Botones CTA:** 18+ (incluye nuevo botón tienda)
- **Productos en tienda:** 3 (fácil de expandir)
- **Plataformas de venta:** Amazon + Shopify

## 🎯 Optimizaciones Incluidas

- ✅ SEO meta tags completos
- ✅ Open Graph para redes sociales
- ✅ Imágenes lazy load (via browser nativo)
- ✅ CSS optimizado con variables
- ✅ JavaScript minificado inline
- ✅ Fuentes via CDN con preconnect
- ✅ Font Awesome via CDN
- ✅ Responsive para plataformas de tienda en móvil

## 🌐 Compatibilidad

- ✅ Chrome, Firefox, Safari, Edge (últimas versiones)
- ✅ Móvil: iOS Safari, Chrome Android
- ✅ Tablets: iPad, Android tablets
- ✅ Responsive desde 320px hasta 4K

## 💰 Costos

| Servicio | Costo Mensual |
|---|---|
| Cloudflare Pages | **$0** (gratis para siempre) |
| Tally.so formularios | **$0** (gratis 100 envíos/mes) |
| Google Drive (PDF) | **$0** (15GB gratis) |
| WhatsApp Business | **$0** (gratis) |
| **TOTAL** | **$0 al mes** 🎉 |

## 📞 Soporte

- Email: contacto@isaacpazebook.com
- Facebook: [Isaac Paz - Bienestar Digital](https://www.facebook.com/profile.php?id=61588545180999)
- WhatsApp: https://chat.whatsapp.com/G63cumGwyTl9WCyfqQwZbX?mode=gi_t

## 🎨 Paleta de Colores

```css
Navy: #0A1F3C
Dorado: #C9A84C
Verde: #1B5E3B
Naranja (Amazon): #FF6600
Verde Shopify: #96BF48
Rojo urgencia: #E63946
WhatsApp: #25D366
Rosa neón (botón tienda): #FF10F0
Cyan neón (botón tienda): #00F5FF
```

## 🆕 Cambios en Esta Actualización

1. ✨ **Foto familiar tranquilizadora** en sección "Mi Historia"
2. ✨ **Botón flotante de tienda** con colores fluorescentes (rosa + cyan) y animación pulse visible
3. ✨ **Integración Shopify** con card destacada junto a Amazon
4. ✨ **WhatsApp actualizado** en 5 lugares diferentes del sitio
5. ✨ **Responsive mejorado** para las cards de plataformas en móvil

## 📝 Licencia

© 2025 Isaac Paz - Bienestar Digital. Todos los derechos reservados.

---

**🚀 ¡LISTO PARA PUBLICAR!** Sube `index.html` a Cloudflare Pages y tu sitio estará online en menos de 5 minutos.