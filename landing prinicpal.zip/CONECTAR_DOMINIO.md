# 🌐 GUÍA: Conectar isaacpazebook.com a Cloudflare Pages

## 📋 Requisitos previos:
- ✅ Tu sitio ya debe estar subido a Cloudflare Pages
- ✅ Tu dominio está registrado en Porkbun

---

## 🚀 PASO 1: Subir el sitio a Cloudflare Pages

### Si aún NO has subido el sitio:

1. Ve a **[pages.cloudflare.com](https://pages.cloudflare.com)**
2. Inicia sesión o crea cuenta (usa el mismo email que Porkbun si es posible)
3. Clic en **"Upload your static files"**
4. Dale un nombre a tu proyecto: `bienestar-digital` (o el que prefieras)
5. Arrastra y suelta el archivo **`index.html`**
6. Clic en **"Deploy site"**
7. Espera 30 segundos → ¡Tu sitio estará en línea!
8. Verás una URL temporal tipo: `bienestar-digital.pages.dev`

---

## 🔗 PASO 2: Agregar dominio personalizado en Cloudflare Pages

### Una vez tu sitio esté desplegado:

1. En Cloudflare Pages, ve a tu proyecto **"bienestar-digital"**
2. Clic en la pestaña **"Custom domains"** (Dominios personalizados)
3. Clic en **"Set up a domain"** o **"Add domain"**
4. Escribe: **`isaacpazebook.com`**
5. Clic en **"Continue"** o **"Add domain"**

### Cloudflare te mostrará 2 opciones:

---

## 🎯 OPCIÓN A: Dominio ya está en Cloudflare (MÁS FÁCIL)

Si tu dominio **isaacpazebook.com** YA tiene sus nameservers apuntando a Cloudflare:

✅ **Cloudflare detectará automáticamente el dominio**
✅ Te preguntará si quieres agregar los registros DNS necesarios
✅ Clic en **"Activate domain"** → ¡LISTO!

---

## 🎯 OPCIÓN B: Dominio está en Porkbun (NECESITAS CONFIGURAR DNS)

Si tu dominio **todavía usa los nameservers de Porkbun**, sigue estos pasos:

### 🔹 Sub-opción B1: Cambiar nameservers a Cloudflare (RECOMENDADO)

**Ventajas:**
- ✅ Configuración automática
- ✅ CDN gratis de Cloudflare
- ✅ SSL automático
- ✅ Mejor rendimiento

**Pasos:**

1. **En Cloudflare:**
   - Ve a tu dashboard principal de Cloudflare
   - Clic en **"Add site"** o **"Agregar sitio"**
   - Escribe: `isaacpazebook.com`
   - Selecciona plan **"Free"** (gratis)
   - Cloudflare te mostrará 2 nameservers tipo:
     ```
     blake.ns.cloudflare.com
     nola.ns.cloudflare.com
     ```
   - **COPIA ESTOS NAMESERVERS** (los necesitarás en Porkbun)

2. **En Porkbun:**
   - Inicia sesión en [porkbun.com](https://porkbun.com)
   - Ve a **"Domain Management"**
   - Selecciona **`isaacpazebook.com`**
   - Clic en **"Nameservers"**
   - Clic en **"Use custom nameservers"**
   - **Borra los nameservers actuales** (cupcake.porkbun.com, etc.)
   - **Pega los 2 nameservers de Cloudflare:**
     ```
     blake.ns.cloudflare.com
     nola.ns.cloudflare.com
     ```
   - Guarda cambios

3. **Espera propagación:**
   - La propagación puede tomar **5 minutos a 24 horas**
   - Generalmente funciona en **30 minutos**
   - Verifica en: [whatsmydns.net](https://www.whatsmydns.net/#NS/isaacpazebook.com)

4. **Vuelve a Cloudflare Pages:**
   - Una vez propagados los nameservers
   - Ve a tu proyecto → **"Custom domains"**
   - Agrega **`isaacpazebook.com`**
   - Cloudflare lo activará automáticamente ✅

---

### 🔹 Sub-opción B2: Mantener nameservers de Porkbun (Manual)

Si prefieres **NO cambiar los nameservers**, debes configurar DNS manualmente:

**Cloudflare Pages te dará registros DNS para agregar:**

```
Tipo: CNAME
Nombre: isaacpazebook.com (o @)
Apunta a: bienestar-digital.pages.dev
```

```
Tipo: CNAME
Nombre: www
Apunta a: bienestar-digital.pages.dev
```

**En Porkbun:**

1. Ve a **"Domain Management"** → **`isaacpazebook.com`**
2. Clic en **"DNS Records"**
3. **BORRA los registros A actuales** que apuntan a GitHub Pages:
   ```
   185.199.108.153
   185.199.109.153
   185.199.110.153
   185.199.111.153
   ```
4. **Agrega nuevos registros:**

   | Tipo | Host | Answer | TTL |
   |------|------|--------|-----|
   | CNAME | @ | bienestar-digital.pages.dev | 600 |
   | CNAME | www | bienestar-digital.pages.dev | 600 |

5. Guarda cambios
6. Espera **10-30 minutos** para propagación

---

## ✅ PASO 3: Verificar que funciona

### Prueba estos 4 URLs:

1. `https://isaacpazebook.com` → Debe cargar tu sitio ✅
2. `https://www.isaacpazebook.com` → Debe cargar tu sitio ✅
3. `http://isaacpazebook.com` → Debe redirigir a HTTPS ✅
4. `http://www.isaacpazebook.com` → Debe redirigir a HTTPS ✅

---

## 🔒 PASO 4: Activar HTTPS (Automático)

Cloudflare Pages activa **HTTPS automáticamente** (certificado SSL gratis).

- Espera **5-15 minutos** después de agregar el dominio
- El certificado se genera automáticamente
- Verás un candado verde 🔒 en el navegador

---

## 🎯 RESUMEN: ¿Qué opción elegir?

| Opción | Dificultad | Tiempo | Recomendado |
|--------|-----------|--------|-------------|
| **Cambiar nameservers a Cloudflare** | Fácil | 30 min | ⭐⭐⭐⭐⭐ SÍ |
| **Mantener Porkbun con CNAME** | Media | 30 min | ⭐⭐⭐ Funciona |

---

## 🚨 Solución de problemas

### "Domain already exists on Cloudflare"
- Tu dominio ya está en otra cuenta de Cloudflare
- Elimínalo de la otra cuenta primero
- O usa la cuenta donde ya está

### "DNS check failed"
- Espera más tiempo (hasta 48h)
- Verifica los registros DNS en Porkbun
- Limpia caché DNS: `ipconfig /flushdns` (Windows) o `sudo dscacheutil -flushcache` (Mac)

### "SSL certificate pending"
- Es normal, espera 15-30 minutos
- Cloudflare genera el certificado automáticamente

---

## 📞 ¿Necesitas ayuda?

Si encuentras algún problema, dime en qué paso estás y te ayudo. 🚀

---

## ✅ Checklist final:

- [ ] Sitio subido a Cloudflare Pages
- [ ] Dominio agregado en Custom Domains
- [ ] Nameservers apuntando a Cloudflare (o CNAME configurado)
- [ ] DNS propagado (verificado en whatsmydns.net)
- [ ] HTTPS activo (candado verde)
- [ ] www funciona correctamente
- [ ] Sitio carga perfectamente

---

¡Una vez completado esto, tu sitio estará **100% online** en `isaacpazebook.com`! 🎉